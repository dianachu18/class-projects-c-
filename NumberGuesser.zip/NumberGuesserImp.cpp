
// NumberGuesser class Implementation
// Written by: Diana Chu
// Date: 11/7/2022

#include <iostream>
#include "NumberGuesser.h"
using namespace std;

NumberGuesser::NumberGuesser()
{
        lowerBound = 1;
        upperBound = 100;
        initLowerBound = 1;
        initUpperBound = 100;
}

NumberGuesser::NumberGuesser(int l, int u)
{
        lowerBound = l;
        upperBound = u;
        initLowerBound = l;
        initUpperBound = u;
}

NumberGuesser::~NumberGuesser()
{
}

void NumberGuesser::higher()
{
        lowerBound = midpoint +1;
        midpoint = (lowerBound + upperBound)/2;
}

void NumberGuesser::lower()
{
        upperBound = midpoint - 1;
        midpoint = (lowerBound + upperBound)/2;
}

int NumberGuesser::getCurrentGuess()
{
        midpoint = (lowerBound + upperBound)/2;
        return midpoint;
}

void NumberGuesser::reset()
{
        lowerBound = initLowerBound;
        upperBound = initUpperBound;
}

