// NumberGuesser class definition
// Written by: Diana Chu
// Date: 11/7/2022

#ifndef NUMBERGUESSER_H
#define NUMBERGUESSER_H

class NumberGuesser
{
        private:
                int lowerBound;
                int upperBound;
                int initLowerBound;
                int initUpperBound;
                int midpoint = (lowerBound+upperBound)/2;
        public:
                NumberGuesser();
                NumberGuesser(int lowerBound, int upperBound);
                ~NumberGuesser();
                void higher();
                void lower();
                int getCurrentGuess();
                void reset();
};
#endif
