// Number Guesser Main Program
// Written by: Diana Chu
// Date: 11/7/2022

#include <iostream>
#include "NumberGuesser.h"
using namespace std;


int main()
{
        char reply;
        char answer;
        NumberGuesser guesser;
        do{
                cout << "Pick a number between 1-100" << endl;
                cout << "Is the number " << guesser.getCurrentGuess() << "? (h/l/c): ";
                cin >> reply;
                while (reply != 'c')
                {
                        if (reply == 'h')
                        {
                                guesser.higher();
                                cout << "Is the number " << guesser.getCurrentGuess() << "? (h/l/c): ";
                                cin >> reply;

                        }
                        else if (reply == 'l')
                        {
                                guesser.lower();
                                cout << "Is the number " << guesser.getCurrentGuess() << "? (h/l/c): ";
                                cin >> reply;

                        }
                }

                cout << "You pick " << guesser.getCurrentGuess() << "? Great pick." << endl;

                cout << "Do you want to play again? (y/n): ";
                cin >> answer;
                cout << endl;
                if (answer == 'y')
                {
                        guesser.reset();
                }
        } while(answer == 'y');

        NumberGuesser littleGuesser(25,35);
        do{
                cout << "Pick a number between 25-35" << endl;
                cout << "Is the number " << littleGuesser.getCurrentGuess() << "? (h/l/c): ";
                cin >> reply;
                while (reply != 'c')
                {
                        if (reply == 'h')
                        {
                                littleGuesser.higher();
                                cout << "Is the number " << littleGuesser.getCurrentGuess() << "? (h/l/c): ";
                                cin >> reply;

                        }
                        else if (reply == 'l')
                        {
                                littleGuesser.lower();
                                cout << "Is the number " << littleGuesser.getCurrentGuess() << "? (h/l/c): ";
                                cin >> reply;

                        }
                }

                cout << "You pick " << littleGuesser.getCurrentGuess() << "? Great pick." << endl;

                cout << "Do you want to play again? (y/n): ";
                cin >> answer;
                cout << endl;
                if (answer == 'y')
                {
                        littleGuesser.reset();
                }
                else
                {
                        cout << "Goodbye." << endl;
                }

                } while(answer == 'y');


        return 0;
}


/*SAMPLE OUTPUT
[dchu51@hills ~]$ ./a.out
Pick a number between 1-100
Is the number 50? (h/l/c): h
Is the number 75? (h/l/c): h
Is the number 88? (h/l/c): l
Is the number 81? (h/l/c): l
Is the number 78? (h/l/c): l
Is the number 76? (h/l/c): h
Is the number 77? (h/l/c): c
You pick 77? Great pick.
Do you want to play again? (y/n): y

Pick a number between 1-100
Is the number 50? (h/l/c): l
Is the number 25? (h/l/c): l
Is the number 12? (h/l/c): h
Is the number 18? (h/l/c): h
Is the number 21? (h/l/c): h
Is the number 23? (h/l/c): c
You pick 23? Great pick.
Do you want to play again? (y/n): n

Pick a number between 25-35
Is the number 30? (h/l/c): l
Is the number 27? (h/l/c): h
Is the number 28? (h/l/c): h
Is the number 29? (h/l/c): c
You pick 29? Great pick.
Do you want to play again? (y/n): n

Goodbye.
[dchu51@hills ~]$
*/