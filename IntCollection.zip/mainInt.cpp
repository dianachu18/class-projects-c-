// Main program for IntCollection
// Written by: Diana Chu
// date: 11/21/2022

#include <iostream>
#include "IntCollection.h"
using namespace std;

int main()
{
        IntCollection c;

        c.add(45);
        c.add(-210);
        c.add(77);
        c.add(2);
        c.add(-21);
        c.add(42);
        c.add(7);

        //c.addCapacity();

	  cout << "Data for c:" << endl;

        for (int i = 0; i < c.getSize(); i++)
        {
                cout << c.get(i) << endl;
        }

        IntCollection c2(c);

        cout << "Data for c2:" << endl;

        for(int i = 0; i< c2.getSize(); i++)
        {
                cout << c2.get(i) << endl;
        }

        IntCollection c3, c4;

        c4 = c3 = c2;

        cout << "Data for c3:" << endl;

        for(int i = 0; i< c3.getSize(); i++)
        {
                cout << c3.get(i) << endl;
        }


        cout << "Data for c4:" << endl;

        for(int i = 0; i< c4.getSize(); i++)
        {
                cout << c4.get(i) << endl;
        }

        IntCollection c5;

        c5 << 48 << 60 << -360 << 27 << 68 << 42 << 7;


        cout << "Data for c5:" << endl;

        for(int i = 0; i< c5.getSize(); i++)
        {
                cout << c5.get(i) << endl;
        }

        if (c5 == c4)
        {
                cout << "c5 and are equal." << endl;
        }
        else
        {
                cout << "c5 and c4 are not equal." << endl;
        }

        if (c4 == c)
        {
                cout << "c and c4 are equal." << endl;
        }
        else
        {
                cout << "c and c4 are not equal." << endl;
        }

        return 0;
}

/*SAMPLE OUTPUT
45
-210
77
2
-21
42
7
Data for c2:
45
-210
77
2
-21
42
7
Data for c3:
45
-210
77
2
-21
42
7
Data for c4:
45
-210
77
2
-21
42
7
Data for c5:
48
60
-360
27
68
42
7
c5 and c4 are not equal.
c and c4 are equal.

ANSWER TO NUMBER 6:
It will cause an error that says addCapacity() is declared private.

mainInt.cpp: In function ‘int main()’:
mainInt.cpp:21:16: error: ‘void IntCollection::addCapacity()’ is private within this context
   21 |  c.addCapacity();
      |                ^
In file included from mainInt.cpp:6:
IntCollection.h:17:10: note: declared private here
   17 |     void addCapacity(); // a private member function to allocate more memory if necessary
      |          ^~~~~~~~~~~

*/